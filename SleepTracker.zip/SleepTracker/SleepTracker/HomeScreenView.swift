//
//  HomeScreenView.swift
//  SleepTracker
//
//  Created by Harley Scheck on 3/31/25.
//
import SwiftUI
import Charts
// MARK: - Models
struct SleepEntry: Identifiable {
    let id = UUID()
    let day: String
    let hours: Double
    
    static var mockData: [SleepEntry] {
        ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map {
            SleepEntry(day: $0, hours: Double.random(in: 5...9))
        }
    }
}
struct SleepData {
    var duration: Double
    var quality: Double
    var bedTime: Date
    var wakeTime: Date
    var heartRate: Int
    var deep: Int
    var light: Int
    var rem: Int
    
    static var mock: SleepData {
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
        return SleepData(
            duration: 7.5,
            quality: 0.82,
            bedTime: Calendar.current.date(bySettingHour: 23, minute: 45, second: 0, of: yesterday)!,
            wakeTime: Calendar.current.date(bySettingHour: 7, minute: 17, second: 0, of: Date())!,
            heartRate: 52,
            deep: 22,
            light: 55,
            rem: 23
        )
    }
    
    var stages: [(String, Int, Color)] {
        [("Deep", deep, .purple), ("Light", light, .blue), ("REM", rem, .teal)]
    }
}
// MARK: - ViewModel
class SleepViewModel: ObservableObject {
    @Published var weeklyData: [SleepEntry]
    @Published var lastSleep: SleepData
    @Published var sleepTrend: SleepTrend = .improving
    
    enum SleepTrend { case improving, declining, stable }
    
    init() {
        self.weeklyData = SleepEntry.mockData
        self.lastSleep = SleepData.mock
        analyzeTrend()
    }
    
    func logSleep(bedTime: Date, wakeTime: Date, quality: Double, deep: Int, light: Int, rem: Int) {
        // Handle cross-midnight sleep correctly
        var actualWakeTime = wakeTime
        if wakeTime < bedTime {
            // If wake time is before bed time, assume it's the next day
            let calendar = Calendar.current
            if let nextDayWake = calendar.date(byAdding: .day, value: 1, to: wakeTime) {
                actualWakeTime = nextDayWake
            }
        }
        
        let duration = actualWakeTime.timeIntervalSince(bedTime) / 3600
        let day = Calendar.current.shortWeekdaySymbols[Calendar.current.component(.weekday, from: Date()) - 1]
        
        // Update weekly data
        if let index = weeklyData.firstIndex(where: { $0.day == day }) {
            weeklyData[index] = SleepEntry(day: day, hours: max(0, duration))
        } else {
            weeklyData.append(SleepEntry(day: day, hours: max(0, duration)))
        }
        
        // Update last sleep
        lastSleep = SleepData(
            duration: max(0, duration),
            quality: quality,
            bedTime: bedTime,
            wakeTime: actualWakeTime,
            heartRate: Int.random(in: 50...65),
            deep: deep,
            light: light,
            rem: rem
        )
        
        analyzeTrend()
    }
    
    func analyzeTrend() {
        // Smart trend analysis
        let recentAvg = weeklyData.suffix(3).map(\.hours).reduce(0, +) / Double(min(3, weeklyData.count))
        let earlierAvg = weeklyData.prefix(max(0, weeklyData.count - 3)).map(\.hours).reduce(0, +) /
                         Double(max(1, weeklyData.count - 3))
        
        let difference = recentAvg - earlierAvg
        if difference > 0.5 {
            sleepTrend = .improving
        } else if difference < -0.5 {
            sleepTrend = .declining
        } else {
            sleepTrend = .stable
        }
    }
    
    func getSleepRecommendations() -> [(icon: String, title: String, description: String)] {
        let avgDuration = weeklyData.map(\.hours).reduce(0, +) / Double(weeklyData.count)
        var recommendations = [(String, String, String)]()
        
        // Smart personalized recommendations
        if avgDuration < 7 {
            recommendations.append(("clock.badge.exclamationmark.fill",
                                   "Increase Sleep Duration",
                                   "You're averaging \(String(format: "%.1f", avgDuration)) hours. Aim for 7-9 hours."))
        }
        
        if lastSleep.deep < 20 {
            recommendations.append(("moon.zzz.fill",
                                   "Improve Deep Sleep",
                                   "Try to reduce caffeine after 2pm and exercise regularly."))
        }
        
        // Default recommendations if none are triggered
        if recommendations.isEmpty {
            recommendations = [
                ("moon.stars.fill", "Consistent Schedule", "Try to sleep and wake at consistent times."),
                ("bed.double.fill", "Sleep Environment", "Keep your bedroom cool, dark, and quiet.")
            ]
        }
        
        return recommendations
    }
}
// MARK: - Helper Extensions
extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        
        let r = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let g = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let b = Double(rgbValue & 0x0000FF) / 255.0
        
        self.init(red: r, green: g, blue: b)
    }
    
    static let dreamBlue = Color(hex: "4169E1")
    static let dreamPurple = Color(hex: "8A2BE2")
    static let dreamBg = Color(hex: "0D1117")
    static let cardBg = Color(hex: "1E1E2E")
    static let accentCyan = Color(hex: "36D1DC")
}
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
    
    func cardStyle() -> some View {
        self
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 22)
                    .fill(Color.cardBg.opacity(0.8))
                    .shadow(color: Color.purple.opacity(0.2), radius: 10, x: 0, y: 5)
            )
            .padding(.horizontal, 20)
    }
    
    func glowBorder(_ color: Color) -> some View {
        self
            .overlay(
                RoundedRectangle(cornerRadius: 22)
                    .stroke(color, lineWidth: 1.5)
                    .blur(radius: 2)
            )
    }
}
struct RoundedCorner: Shape {
    var radius: CGFloat
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect,
                                byRoundingCorners: corners,
                                cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
// MARK: - UI Components
struct ActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                Text(title).fontWeight(.semibold)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(
                    colors: [color, color.opacity(0.7)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .opacity(0.3)
            )
            .foregroundColor(color)
            .cornerRadius(15)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(color.opacity(0.5), lineWidth: 1)
            )
        }
    }
}
// MARK: - Main View
struct HomeScreenView: View {
    @StateObject private var viewModel = SleepViewModel()
    @State private var showingSleepLogger = false
    @State private var showingInsights = false
    
    var body: some View {
        ZStack {
            // Background
            LinearGradient(colors: [Color.dreamBg, Color(hex: "251A40")],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            
            // Ambient background elements
            ZStack {
                Circle().fill(Color.dreamPurple.opacity(0.1))
                    .frame(width: 300)
                    .blur(radius: 80)
                    .offset(x: -100, y: -200)
                
                Circle().fill(Color.accentCyan.opacity(0.1))
                    .frame(width: 300)
                    .blur(radius: 60)
                    .offset(x: 120, y: 300)
            }
            
            ScrollView {
                VStack(spacing: 25) {
                    Text("Sonho")
                        .font(.custom("Snell Roundhand", size: 42))
                        .foregroundStyle(
                            LinearGradient(colors: [.white, .accentCyan],
                                         startPoint: .leading,
                                         endPoint: .trailing)
                        )
                        .shadow(color: .purple.opacity(0.5), radius: 8)
                        .padding(.top, 40)
                    
                    // Sleep quality card
                    SleepQualityCard(sleepData: viewModel.lastSleep, trend: viewModel.sleepTrend)
                        .onTapGesture {
                            withAnimation(.spring()) {
                                showingSleepLogger = true
                            }
                        }
                    
                    // Weekly sleep pattern card
                    SleepPatternCard(sleepData: viewModel.weeklyData)
                        .onTapGesture {
                            withAnimation(.spring()) {
                                showingInsights = true
                            }
                        }
                    
                    // Sleep stages card
                    SleepStagesCard(sleepStages: viewModel.lastSleep.stages)
                    
                    // Action buttons
                    HStack(spacing: 15) {
                        ActionButton(title: "Log Sleep", icon: "moon.stars.fill", color: .dreamBlue) {
                            withAnimation(.spring()) {
                                showingSleepLogger = true
                            }
                        }
                        
                        ActionButton(title: "View Insights", icon: "chart.bar.fill", color: .dreamPurple) {
                            withAnimation(.spring()) {
                                showingInsights = true
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    
                    Spacer().frame(height: 20)
                }
            }
            
            // Modal sheets
            if showingSleepLogger {
                Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        withAnimation(.spring()) {
                            showingSleepLogger = false
                        }
                    }
                
                SleepLoggerView(isPresented: $showingSleepLogger, viewModel: viewModel)
                    .transition(.move(edge: .bottom))
            }
            
            if showingInsights {
                Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        withAnimation(.spring()) {
                            showingInsights = false
                        }
                    }
                
                InsightsView(isPresented: $showingInsights, viewModel: viewModel)
                    .transition(.move(edge: .bottom))
            }
        }
    }
}
struct SleepQualityCard: View {
    let sleepData: SleepData
    let trend: SleepViewModel.SleepTrend
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: date)
    }
    
    private func formatHours(_ hours: Double) -> String {
        // Fixed to ensure non-negative hours
        let positiveHours = max(0, hours)
        let h = Int(positiveHours)
        let m = Int((positiveHours - Double(h)) * 60)
        return "\(h)h \(m)m"
    }
    
    var body: some View {
        VStack {
            HStack {
                VStack(alignment: .leading) {
                    Text("Last Night's Sleep")
                        .foregroundColor(.white.opacity(0.8))
                        .font(.system(size: 16, weight: .medium, design: .rounded))
                    
                    HStack(spacing: 12) {
                        Text(formatHours(sleepData.duration))
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        
                        // Show trend indicator with animation
                        Image(systemName: trendIcon)
                            .foregroundColor(trendColor)
                            .font(.system(size: 18, weight: .semibold))
                            .padding(8)
                            .background(trendColor.opacity(0.2))
                            .clipShape(Circle())
                    }
                }
                
                Spacer()
                
                ZStack {
                    Circle()
                        .stroke(LinearGradient(colors: [.gray.opacity(0.2), .white.opacity(0.05)],
                                               startPoint: .top,
                                               endPoint: .bottom), lineWidth: 8)
                    
                    Circle()
                        .trim(from: 0, to: CGFloat(sleepData.quality))
                        .stroke(
                            LinearGradient(colors: [qualityColor.opacity(0.7), qualityColor],
                                           startPoint: .leading,
                                           endPoint: .trailing),
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                    
                    Text("\(Int(sleepData.quality * 100))%")
                        .foregroundColor(.white)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                }
                .frame(width: 70, height: 70)
            }
            
            Divider()
                .background(LinearGradient(colors: [.clear, .white.opacity(0.2), .clear],
                                           startPoint: .leading,
                                           endPoint: .trailing))
            
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: "moon.fill")
                        .foregroundColor(.accentCyan)
                        .font(.system(size: 14))
                    Text(formatTime(sleepData.bedTime))
                        .foregroundColor(.white)
                        .font(.system(size: 14, design: .rounded))
                }
                
                Spacer()
                
                HStack(spacing: 6) {
                    Image(systemName: "sun.max.fill")
                        .foregroundColor(.yellow)
                        .font(.system(size: 14))
                    Text(formatTime(sleepData.wakeTime))
                        .foregroundColor(.white)
                        .font(.system(size: 14, design: .rounded))
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 22)
                .fill(Color.cardBg.opacity(0.8))
                .shadow(color: qualityColor.opacity(0.2), radius: 8, x: 0, y: 4)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(LinearGradient(colors: [qualityColor.opacity(0.5), qualityColor.opacity(0.1)],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing), lineWidth: 1.5)
        )
        .padding(.horizontal, 20)
    }
    
    private var qualityColor: Color {
        if sleepData.quality > 0.7 { return .green }
        if sleepData.quality > 0.4 { return .yellow }
        return .red
    }
    
    private var trendIcon: String {
        switch trend {
        case .improving: return "arrow.up.circle.fill"
        case .declining: return "arrow.down.circle.fill"
        case .stable: return "arrow.right.circle.fill"
        }
    }
    
    private var trendColor: Color {
        switch trend {
        case .improving: return .green
        case .declining: return .red
        case .stable: return .yellow
        }
    }
}
struct SleepPatternCard: View {
    let sleepData: [SleepEntry]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Weekly Sleep Pattern")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .padding(.horizontal)
            
            Chart {
                ForEach(sleepData) { entry in
                    BarMark(x: .value("Day", entry.day), y: .value("Hours", entry.hours))
                        .foregroundStyle(
                            entry.hours >= 7 ?
                                LinearGradient(colors: [.blue.opacity(0.7), .green.opacity(0.8)],
                                              startPoint: .bottom,
                                              endPoint: .top) :
                                LinearGradient(colors: [.blue.opacity(0.7), .orange.opacity(0.8)],
                                              startPoint: .bottom,
                                              endPoint: .top)
                        )
                        .cornerRadius(8)
                }
                
                RuleMark(y: .value("Ideal", 8))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 5]))
                    .foregroundStyle(Color.green.opacity(0.7))
                    .annotation(position: .leading) {
                        Text("Ideal")
                            .font(.caption)
                            .foregroundColor(.green.opacity(0.7))
                    }
            }
            .frame(height: 200)
            .chartYScale(domain: 0...12)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 22)
                .fill(Color.cardBg.opacity(0.8))
                .shadow(color: Color.blue.opacity(0.2), radius: 8, x: 0, y: 4)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(LinearGradient(colors: [.blue.opacity(0.5), .blue.opacity(0.1)],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing), lineWidth: 1.5)
        )
        .padding(.horizontal, 20)
    }
}
struct SleepStagesCard: View {
    let sleepStages: [(String, Int, Color)]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Sleep Stages")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .padding(.horizontal)
            
            HStack {
                ForEach(sleepStages, id: \.0) { stage in
                    VStack {
                        ZStack {
                            Circle()
                                .stroke(Color.white.opacity(0.1), lineWidth: 8)
                            
                            Circle()
                                .trim(from: 0, to: CGFloat(stage.1) / 100)
                                .stroke(
                                    LinearGradient(colors: [stage.2.opacity(0.7), stage.2],
                                                   startPoint: .leading,
                                                   endPoint: .trailing),
                                    style: StrokeStyle(lineWidth: 8, lineCap: .round)
                                )
                                .rotationEffect(.degrees(-90))
                            
                            VStack(spacing: 0) {
                                Text("\(stage.1)%")
                                    .foregroundColor(.white)
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                            }
                        }
                        .frame(width: 70, height: 70)
                        
                        Text(stage.0)
                            .foregroundColor(.white.opacity(0.8))
                            .font(.system(size: 14, design: .rounded))
                    }
                    
                    if stage.0 != "REM" { Spacer() }
                }
            }
            .padding()
        }
        .padding(.vertical)
        .background(
            RoundedRectangle(cornerRadius: 22)
                .fill(Color.cardBg.opacity(0.8))
                .shadow(color: Color.purple.opacity(0.2), radius: 8, x: 0, y: 4)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22)
                .stroke(LinearGradient(colors: [.purple.opacity(0.5), .purple.opacity(0.1)],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing), lineWidth: 1.5)
        )
        .padding(.horizontal, 20)
    }
}
// MARK: - Modal Views
struct SleepLoggerView: View {
    @Binding var isPresented: Bool
    var viewModel: SleepViewModel
    
    @State private var bedTime = Calendar.current.date(bySettingHour: 22, minute: 0, second: 0, of: Date())!
    @State private var wakeTime = Calendar.current.date(bySettingHour: 7, minute: 0, second: 0, of: Date())!
    @State private var sleepQuality = 0.75
    @State private var deepSleep = 20
    @State private var lightSleep = 60
    @State private var remSleep = 20
    
    private var totalSleepMinutes: Int {
        // Handle potential cross-midnight sleep time
        var adjustedWakeTime = wakeTime
        if wakeTime < bedTime {
            if let nextDayWake = Calendar.current.date(byAdding: .day, value: 1, to: wakeTime) {
                adjustedWakeTime = nextDayWake
            }
        }
        return Int(adjustedWakeTime.timeIntervalSince(bedTime) / 60)
    }
    
    private var sleepDuration: String {
        let hours = totalSleepMinutes / 60
        let minutes = totalSleepMinutes % 60
        return "\(hours)h \(minutes)m"
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header with blur effect
            ZStack {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .frame(height: 60)
                
                HStack {
                    Text("Log Your Sleep")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Button {
                        withAnimation(.spring()) {
                            isPresented = false
                        }
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundColor(.white.opacity(0.7))
                    }
                }
                .padding(.horizontal)
            }
            
            ScrollView {
                VStack(spacing: 20) {
                    // Time selectors
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "clock.fill")
                                .foregroundColor(.dreamBlue)
                            Text("Sleep Schedule")
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                        
                        HStack(spacing: 20) {
                            VStack(alignment: .leading) {
                                HStack {
                                    Image(systemName: "moon.fill")
                                        .foregroundColor(.accentCyan)
                                        .font(.caption)
                                    Text("Bedtime")
                                        .foregroundColor(.white.opacity(0.7))
                                        .font(.subheadline)
                                }
                                DatePicker("", selection: $bedTime, displayedComponents: .hourAndMinute)
                                    .labelsHidden()
                                    .colorScheme(.dark)
                                    .datePickerStyle(.compact)
                            }
                            
                            Spacer()
                            
                            VStack(alignment: .trailing) {
                                HStack {
                                    Text("Wake up")
                                        .foregroundColor(.white.opacity(0.7))
                                        .font(.subheadline)
                                    Image(systemName: "sun.max.fill")
                                        .foregroundColor(.yellow)
                                        .font(.caption)
                                }
                                DatePicker("", selection: $wakeTime, displayedComponents: .hourAndMinute)
                                    .labelsHidden()
                                    .colorScheme(.dark)
                                    .datePickerStyle(.compact)
                            }
                        }
                        
                        // Smart sleep duration feedback with animation
                        HStack {
                            Text("Sleep duration: ")
                                .foregroundColor(.white.opacity(0.7))
                            
                            Text(sleepDuration)
                                .foregroundColor(.white)
                                .fontWeight(.medium)
                            
                            Spacer()
                            
                            Image(systemName: totalSleepMinutes >= 420 ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                                .foregroundColor(totalSleepMinutes >= 420 ? .green : .orange)
                                .font(.system(size: 18))
                                .padding(6)
                                .background(
                                    (totalSleepMinutes >= 420 ? Color.green : Color.orange)
                                        .opacity(0.2)
                                        .clipShape(Circle())
                                )
                        }
                        .padding(.top, 5)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.cardBg.opacity(0.8))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(Color.dreamBlue.opacity(0.5), lineWidth: 1)
                    )
                    
                    // Quality slider
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "heart.fill")
                                .foregroundColor(.red)
                            Text("Sleep Quality")
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                        
                        HStack {
                            Text("Poor")
                                .foregroundColor(.white.opacity(0.6))
                                .font(.caption)
                            
                            Spacer()
                            
                            Text("\(Int(sleepQuality * 100))%")
                                .foregroundColor(
                                    sleepQuality > 0.7 ? .green : sleepQuality > 0.4 ? .yellow : .red
                                )
                                .font(.headline)
                            
                            Spacer()
                            
                            Text("Excellent")
                                .foregroundColor(.white.opacity(0.6))
                                .font(.caption)
                        }
                        
                        Slider(value: $sleepQuality, in: 0...1, step: 0.01)
                            .tint(
                                LinearGradient(colors: [.red, .yellow, .green],
                                               startPoint: .leading,
                                               endPoint: .trailing)
                            )
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.cardBg.opacity(0.8))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(Color.red.opacity(0.5), lineWidth: 1)
                    )
                    
                    // Sleep stages
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "chart.pie.fill")
                                .foregroundColor(.purple)
                            Text("Sleep Stages")
                                .foregroundColor(.white)
                                .font(.headline)
                        }
                        
                        VStack(alignment: .leading, spacing: 12) {
                            ForEach([
                                ("Deep Sleep", $deepSleep, Color.purple),
                                ("Light Sleep", $lightSleep, Color.blue),
                                ("REM Sleep", $remSleep, Color.teal)
                            ], id: \.0) { item in
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack {
                                        Text(item.0)
                                            .foregroundColor(.white.opacity(0.8))
                                            .font(.subheadline)
                                        
                                        Spacer()
                                        
                                        Text("\(item.1.wrappedValue)%")
                                            .foregroundColor(item.2)
                                            .fontWeight(.medium)
                                    }
                                    
                                    Slider(value: Binding(
                                        get: { Double(item.1.wrappedValue) },
                                        set: { item.1.wrappedValue = Int($0) }
                                    ), in: 0...100, step: 1).tint(item.2)
                                }
                            }
                                                        
                                                        // Validation for sleep stages total = 100%
                                                        let total = deepSleep + lightSleep + remSleep
                                                        HStack {
                                                            Text("Total: \(total)%")
                                                                .foregroundColor(total == 100 ? .green : .red)
                                                                .fontWeight(.medium)
                                                            
                                                            Spacer()
                                                            
                                                            if total != 100 {
                                                                Text("Must equal 100%")
                                                                    .foregroundColor(.red)
                                                                    .font(.caption)
                                                            }
                                                        }
                                                        .padding(.top, 5)
                                                    }
                                                }
                                                .padding()
                                                .background(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .fill(Color.cardBg.opacity(0.8))
                                                )
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .stroke(Color.purple.opacity(0.5), lineWidth: 1)
                                                )
                                                
                                                // Submit button
                                                Button {
                                                    if deepSleep + lightSleep + remSleep == 100 {
                                                        viewModel.logSleep(
                                                            bedTime: bedTime,
                                                            wakeTime: wakeTime,
                                                            quality: sleepQuality,
                                                            deep: deepSleep,
                                                            light: lightSleep,
                                                            rem: remSleep
                                                        )
                                                        
                                                        withAnimation(.spring()) {
                                                            isPresented = false
                                                        }
                                                    }
                                                } label: {
                                                    HStack {
                                                        Text("Save Sleep Data")
                                                            .fontWeight(.semibold)
                                                        Image(systemName: "arrow.right.circle.fill")
                                                    }
                                                    .padding()
                                                    .frame(maxWidth: .infinity)
                                                    .background(
                                                        LinearGradient(
                                                            colors: [Color.dreamPurple, Color.dreamBlue],
                                                            startPoint: .leading,
                                                            endPoint: .trailing
                                                        )
                                                        .opacity(deepSleep + lightSleep + remSleep == 100 ? 1.0 : 0.5)
                                                    )
                                                    .foregroundColor(.white)
                                                    .cornerRadius(15)
                                                    .shadow(color: Color.dreamPurple.opacity(0.5), radius: 5, x: 0, y: 3)
                                                }
                                                .disabled(deepSleep + lightSleep + remSleep != 100)
                                            }
                                            .padding(.horizontal)
                                            .padding(.top)
                                            .padding(.bottom, 30)
                                        }
                                    }
                                    .background(
                                        Color.dreamBg
                                            .edgesIgnoringSafeArea(.all)
                                    )
                                    .cornerRadius(30, corners: [.topLeft, .topRight])
                                    .frame(maxHeight: UIScreen.main.bounds.height * 0.85)
                                    .transition(.move(edge: .bottom))
                                }
                            }
                            struct InsightsView: View {
                                @Binding var isPresented: Bool
                                var viewModel: SleepViewModel
                                
                                var body: some View {
                                    VStack(spacing: 0) {
                                        // Header with blur effect
                                        ZStack {
                                            Rectangle()
                                                .fill(.ultraThinMaterial)
                                                .frame(height: 60)
                                            
                                            HStack {
                                                Text("Sleep Insights")
                                                    .font(.title2)
                                                    .fontWeight(.semibold)
                                                    .foregroundColor(.white)
                                                
                                                Spacer()
                                                
                                                Button {
                                                    withAnimation(.spring()) {
                                                        isPresented = false
                                                    }
                                                } label: {
                                                    Image(systemName: "xmark.circle.fill")
                                                        .font(.title2)
                                                        .foregroundColor(.white.opacity(0.7))
                                                }
                                            }
                                            .padding(.horizontal)
                                        }
                                        
                                        ScrollView {
                                            VStack(spacing: 20) {
                                                // Sleep score card
                                                VStack(alignment: .leading, spacing: 15) {
                                                    Text("Sleep Score")
                                                        .font(.headline)
                                                        .foregroundColor(.white)
                                                    
                                                    HStack {
                                                        // Weekly average display
                                                        let weeklyAvg = viewModel.weeklyData.map(\.hours).reduce(0, +) / Double(viewModel.weeklyData.count)
                                                        
                                                        ZStack {
                                                            Circle()
                                                                .stroke(Color.white.opacity(0.1), lineWidth: 16)
                                                                .frame(width: 120, height: 120)
                                                            
                                                            // Calculate score based on how close to ideal 8 hours
                                                            let score = min(1.0, weeklyAvg / 8.0)
                                                            Circle()
                                                                .trim(from: 0, to: CGFloat(score))
                                                                .stroke(
                                                                    LinearGradient(
                                                                        colors: [.blue, .purple, .pink],
                                                                        startPoint: .leading,
                                                                        endPoint: .trailing
                                                                    ),
                                                                    style: StrokeStyle(lineWidth: 16, lineCap: .round)
                                                                )
                                                                .frame(width: 120, height: 120)
                                                                .rotationEffect(.degrees(-90))
                                                            
                                                            VStack(spacing: 0) {
                                                                Text("\(Int(score * 100))")
                                                                    .font(.system(size: 32, weight: .bold))
                                                                    .foregroundColor(.white)
                                                                Text("out of 100")
                                                                    .font(.caption)
                                                                    .foregroundColor(.white.opacity(0.7))
                                                            }
                                                        }
                                                        
                                                        Spacer()
                                                        
                                                        VStack(alignment: .leading) {
                                                            ScoreDetailRow(icon: "bed.double.fill",
                                                                           text: "Avg. Duration",
                                                                           value: String(format: "%.1f hrs", weeklyAvg))
                                                            
                                                            ScoreDetailRow(icon: "repeat",
                                                                           text: "Consistency",
                                                                           value: consistencyScore)
                                                            
                                                            ScoreDetailRow(icon: "waveform.path.ecg",
                                                                           text: "Quality",
                                                                           value: "\(Int(viewModel.lastSleep.quality * 100))%")
                                                        }
                                                    }
                                                }
                                                .padding()
                                                .background(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .fill(Color.cardBg.opacity(0.8))
                                                )
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .stroke(
                                                            LinearGradient(
                                                                colors: [.blue.opacity(0.5), .purple.opacity(0.5)],
                                                                startPoint: .leading,
                                                                endPoint: .trailing
                                                            ),
                                                            lineWidth: 1
                                                        )
                                                )
                                                
                                                // Smart recommendations
                                                VStack(alignment: .leading, spacing: 15) {
                                                    Text("Personalized Recommendations")
                                                        .font(.headline)
                                                        .foregroundColor(.white)
                                                    
                                                    ForEach(viewModel.getSleepRecommendations(), id: \.title) { recommendation in
                                                        HStack(alignment: .top, spacing: 15) {
                                                            Image(systemName: recommendation.icon)
                                                                .font(.system(size: 24))
                                                                .foregroundColor(.accentCyan)
                                                                .frame(width: 32)
                                                            
                                                            VStack(alignment: .leading, spacing: 4) {
                                                                Text(recommendation.title)
                                                                    .font(.system(size: 16, weight: .semibold))
                                                                    .foregroundColor(.white)
                                                                
                                                                Text(recommendation.description)
                                                                    .font(.system(size: 14))
                                                                    .foregroundColor(.white.opacity(0.7))
                                                                    .fixedSize(horizontal: false, vertical: true)
                                                            }
                                                        }
                                                        .padding()
                                                        .background(
                                                            RoundedRectangle(cornerRadius: 12)
                                                                .fill(Color.cardBg.opacity(0.5))
                                                        )
                                                        .overlay(
                                                            RoundedRectangle(cornerRadius: 12)
                                                                .stroke(Color.accentCyan.opacity(0.3), lineWidth: 1)
                                                        )
                                                    }
                                                }
                                                .padding()
                                                .background(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .fill(Color.cardBg.opacity(0.8))
                                                )
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .stroke(Color.accentCyan.opacity(0.5), lineWidth: 1)
                                                )
                                                
                                                // Sleep trend analysis
                                                VStack(alignment: .leading, spacing: 15) {
                                                    Text("Sleep Trend Analysis")
                                                        .font(.headline)
                                                        .foregroundColor(.white)
                                                    
                                                    VStack(alignment: .leading) {
                                                        // Calculate metrics
                                                        let avgDuration = viewModel.weeklyData.map(\.hours).reduce(0, +) / Double(viewModel.weeklyData.count)
                                                        let minDuration = viewModel.weeklyData.map(\.hours).min() ?? 0
                                                        let maxDuration = viewModel.weeklyData.map(\.hours).max() ?? 0
                                                        
                                                        HStack {
                                                            TrendMetricView(title: "Average", value: String(format: "%.1f hrs", avgDuration))
                                                            Spacer()
                                                            TrendMetricView(title: "Minimum", value: String(format: "%.1f hrs", minDuration))
                                                            Spacer()
                                                            TrendMetricView(title: "Maximum", value: String(format: "%.1f hrs", maxDuration))
                                                        }
                                                        
                                                        Divider()
                                                            .background(Color.white.opacity(0.2))
                                                            .padding(.vertical, 10)
                                                        
                                                        // Trend narrative
                                                        HStack(alignment: .top) {
                                                            Image(systemName: trendIcon)
                                                                .foregroundColor(trendColor)
                                                                .font(.system(size: 20))
                                                                .padding(8)
                                                                .background(trendColor.opacity(0.2))
                                                                .clipShape(Circle())
                                                            
                                                            VStack(alignment: .leading, spacing: 5) {
                                                                Text(trendTitle)
                                                                    .font(.system(size: 16, weight: .semibold))
                                                                    .foregroundColor(.white)
                                                                
                                                                Text(trendDescription)
                                                                    .font(.system(size: 14))
                                                                    .foregroundColor(.white.opacity(0.7))
                                                                    .fixedSize(horizontal: false, vertical: true)
                                                            }
                                                        }
                                                    }
                                                }
                                                .padding()
                                                .background(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .fill(Color.cardBg.opacity(0.8))
                                                )
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 15)
                                                        .stroke(Color.dreamPurple.opacity(0.5), lineWidth: 1)
                                                )
                                            }
                                            .padding(.horizontal)
                                            .padding(.top)
                                            .padding(.bottom, 30)
                                        }
                                    }
                                    .background(
                                        Color.dreamBg
                                            .edgesIgnoringSafeArea(.all)
                                    )
                                    .cornerRadius(30, corners: [.topLeft, .topRight])
                                    .frame(maxHeight: UIScreen.main.bounds.height * 0.85)
                                    .transition(.move(edge: .bottom))
                                }
                                
                                private var consistencyScore: String {
                                    let hours = viewModel.weeklyData.map(\.hours)
                                    if hours.count < 2 { return "N/A" }
                                    
                                    // Calculate standard deviation to measure consistency
                                    let mean = hours.reduce(0, +) / Double(hours.count)
                                    let variance = hours.map { pow($0 - mean, 2) }.reduce(0, +) / Double(hours.count)
                                    let stdDev = sqrt(variance)
                                    
                                    // Lower std dev means better consistency
                                    if stdDev < 0.5 { return "Excellent" }
                                    if stdDev < 1.0 { return "Good" }
                                    if stdDev < 1.5 { return "Fair" }
                                    return "Poor"
                                }
                                
                                private var trendIcon: String {
                                    switch viewModel.sleepTrend {
                                    case .improving: return "arrow.up.right"
                                    case .declining: return "arrow.down.right"
                                    case .stable: return "arrow.right"
                                    }
                                }
                                
                                private var trendColor: Color {
                                    switch viewModel.sleepTrend {
                                    case .improving: return .green
                                    case .declining: return .red
                                    case .stable: return .yellow
                                    }
                                }
                                
                                private var trendTitle: String {
                                    switch viewModel.sleepTrend {
                                    case .improving: return "Your sleep is improving"
                                    case .declining: return "Your sleep is declining"
                                    case .stable: return "Your sleep is stable"
                                    }
                                }
                                
                                private var trendDescription: String {
                                    switch viewModel.sleepTrend {
                                    case .improving:
                                        return "You're getting more sleep compared to earlier this week. Keep up the good habits!"
                                    case .declining:
                                        return "Your sleep duration has been decreasing. Try to maintain a more consistent sleep schedule."
                                    case .stable:
                                        return "Your sleep pattern has been consistent throughout the week."
                                    }
                                }
                            }
                            // Helper components
                            struct ScoreDetailRow: View {
                                let icon: String
                                let text: String
                                let value: String
                                
                                var body: some View {
                                    HStack {
                                        Image(systemName: icon)
                                            .foregroundColor(.accentCyan)
                                            .frame(width: 20)
                                        Text(text)
                                            .foregroundColor(.white.opacity(0.8))
                                        Spacer()
                                        Text(value)
                                            .foregroundColor(.white)
                                            .fontWeight(.medium)
                                    }
                                    .padding(.vertical, 6)
                                }
                            }
                            struct TrendMetricView: View {
                                let title: String
                                let value: String
                                
                                var body: some View {
                                    VStack(spacing: 4) {
                                        Text(title)
                                            .font(.system(size: 14))
                                            .foregroundColor(.white.opacity(0.7))
                                        Text(value)
                                            .font(.system(size: 18, weight: .semibold))
                                            .foregroundColor(.white)
                                    }
                                }
                            }
//
//                            // Preview
//                            struct HomeScreenView_Previews: PreviewProvider {
//                                static var previews: some View {
//                                    HomeScreenView()
//                                        .preferredColorScheme(.dark)
//                                }
//                            }

