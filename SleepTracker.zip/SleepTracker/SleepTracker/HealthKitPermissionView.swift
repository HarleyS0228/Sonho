//
//  HealthKitPermissionView.swift
//  SleepTracker
//
//  Created by Harley Scheck on 3/31/25.
//

import SwiftUI
import HealthKit

struct HealthKitPermissionView: View {
    var onFinish: () -> Void  

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.purple, Color.blue]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 30) {
                Text("Track Your Sleep")
                    .font(Font.custom("Snell Roundhand", size: 36))
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                    .padding(.top, 50)

                Image(systemName: "moon.zzz.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
                    .shadow(radius: 5)

                Text("Allow Sleep Tracker to access your sleep data from HealthKit to help monitor your rest patterns.")
                    .font(.system(size: 18))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)

                VStack(spacing: 20) {
                    Button(action: {
                        requestHealthKitPermissions()
                    }) {
                        Text("Enable Health Data")
                            .font(.title3)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(hue: 0.65, saturation: 0.6, brightness: 0.6)) // Soft purple-blue
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(color: Color.white.opacity(0.2), radius: 4, x: 0, y: 2)
                    }

                    Button(action: {
                        onFinish()
                    }) {
                        Text("Not Now")
                            .foregroundColor(Color(hue: 0.65, saturation: 0.2, brightness: 0.7)) // Muted lavender-gray
                            .padding(.vertical, 8)
                    }
                }
                .padding(.horizontal, 40)

                Spacer()
            }
        }
    }

    private func requestHealthKitPermissions() {
        UserDefaults.standard.set(true, forKey: "HealthKitPermissionGranted")
        onFinish()
    }
}
