//
//  SplashScreenView.swift
//  SleepTracker
//
//  Created by Harley Scheck on 3/31/25.
//

import SwiftUI

struct SplashScreenView: View {
    var onFinish: () -> Void
    @State private var logoOpacity = 0.0
    @State private var logoScale: CGFloat = 0.8
    @State private var starsOffset = CGSize(width: 0, height: 0)

    var body: some View {
        ZStack {
            // Updated background to match HomeScreenView
            LinearGradient(colors: [Color.dreamBg, Color(hex: "251A40")],
                       startPoint: .topLeading,
                       endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            
            // Ambient background elements from HomeScreenView
            ZStack {
                Circle().fill(Color.dreamPurple.opacity(0.1))
                    .frame(width: 300)
                    .blur(radius: 80)
                    .offset(x: -100, y: -200)
                
                Circle().fill(Color.accentCyan.opacity(0.1))
                    .frame(width: 300)
                    .blur(radius: 60)
                    .offset(x: 120, y: 300)
            }
            
            // Keep the moving stars animation
            StarsView()
                .offset(starsOffset)
                .onAppear {
                    withAnimation(Animation.linear(duration: 5).repeatForever(autoreverses: true)) {
                        starsOffset = CGSize(width: 20, height: 10)
                    }
                }
            
            VStack {
                // Updated text style to match HomeScreenView
                Text("Sonho")
                    .font(.custom("Snell Roundhand", size: 42))
                    .foregroundStyle(
                        LinearGradient(colors: [.white, .accentCyan],
                                     startPoint: .leading,
                                     endPoint: .trailing)
                    )
                    .shadow(color: .purple.opacity(0.5), radius: 8)
                    .padding(.bottom, 20)

                Image(systemName: "moon.zzz.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .foregroundStyle(
                        LinearGradient(colors: [.white, .accentCyan],
                                     startPoint: .top,
                                     endPoint: .bottom)
                    )
                    .opacity(logoOpacity)
                    .scaleEffect(logoScale)
                    .shadow(color: .purple.opacity(0.5), radius: 8)
                    .onAppear {
                        withAnimation(.easeIn(duration: 1.5)) {
                            logoOpacity = 1.0
                            logoScale = 1.0
                        }
                    }
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                withAnimation {
                    onFinish()
                }
            }
        }
    }
}

struct StarsView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                ForEach(0..<50, id: \.self) { _ in
                    Circle()
                        .fill(Color.white.opacity(0.7))
                        .frame(width: CGFloat.random(in: 2...5), height: CGFloat.random(in: 2...5))
                        .position(
                            x: CGFloat.random(in: 0...geometry.size.width),
                            y: CGFloat.random(in: 0...geometry.size.height)
                        )
                }
            }
        }
    }
}

// Preview Provider
struct SplashScreenView_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreenView(onFinish: {})
    }
}
