//
//  DreamflowLogo.swift
//  SleepTracker
//
//  Created by Harley Scheck on 4/30/25.
//

import SwiftUI

struct DreamFlowLogoView: View {
    var size: CGFloat = 200
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.23)
                .fill(
                    LinearGradient(
                        colors: [Color.dreamBg, Color(hex: "251A40")],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size, height: size)
            
            Circle()
                .fill(Color.dreamPurple.opacity(0.2))
                .frame(width: size * 0.4)
                .blur(radius: size * 0.1)
                .offset(x: -size * 0.2, y: -size * 0.2)
            
            Circle()
                .fill(Color.accentCyan.opacity(0.2))
                .frame(width: size * 0.4)
                .blur(radius: size * 0.1)
                .offset(x: size * 0.2, y: size * 0.2)
            

            ZStack {
                LinearGradient(
                    colors: [Color.dreamPurple, Color.accentCyan],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .clipShape(Circle())
                .frame(width: size * 0.5, height: size * 0.5)
                .mask(
                    CrescentMask()
                        .frame(width: size * 0.5, height: size * 0.5)
                )
            }
            .frame(width: size, height: size, alignment: .center)
            .offset(x: size * 0.05)
            .shadow(color: Color.accentCyan.opacity(0.5), radius: size * 0.05)
            

            ForEach(0..<5, id: \.self) { index in
                Circle()
                    .fill(Color.white.opacity(Double.random(in: 0.6...0.9)))
                    .frame(width: size * 0.008, height: size * 0.008)
                    .position(
                        x: size * (0.3 + 0.4 * CGFloat(sin(Double(index) * 1.2))),
                        y: size * (0.3 + 0.4 * CGFloat(cos(Double(index) * 1.2)))
                    )
            }
        }
        .frame(width: size, height: size)
    }
}


struct CrescentMask: View {
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            
            ZStack {
                Circle()
                    .frame(width: width, height: height)
                
                Circle()
                    .offset(x: width * 0.25)
                    .frame(width: width * 0.95, height: height * 0.95)
                    .blendMode(.destinationOut)
            }
        }
    }
}

struct DreamFlowLogoView_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            DreamFlowLogoView(size: 200)
        }
    }
}
