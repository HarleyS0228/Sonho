//
//  SleepTrackerApp.swift
//  SleepTracker
//
//  Created by Harley Scheck on 3/28/25.
//

import SwiftUI

@main
struct SleepTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
