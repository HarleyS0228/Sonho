//
//  ContentView.swift
//  SleepTracker
//
//  Created by Harley Scheck on 3/28/25.
//

import SwiftUI

struct ContentView: View {
    @State private var currentScreen: Screen = .splash

    enum Screen {
        case splash, permissions, home
    }

    var body: some View {
        switch currentScreen {
        case .splash:
            SplashScreenView {
                let hasRequestedHealthKit = UserDefaults.standard.bool(forKey: "HealthKitPermissionGranted")
                withAnimation {
                    currentScreen = hasRequestedHealthKit ? .home : .permissions
                }
            }
        case .permissions:
            HealthKitPermissionView {
                UserDefaults.standard.set(true, forKey: "HealthKitPermissionGranted")
                withAnimation {
                    currentScreen = .home
                }
            }
        case .home:
            HomeScreenView()
        }
    }
}

#Preview {
    ContentView()
}
